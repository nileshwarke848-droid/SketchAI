# SketchAI 345-class model — metrics and provenance

## What this is

SketchAI's own classifier trained on the Google Quick Draw dataset.
It is **not** Google's model, not AutoDraw, and not a third-party checkpoint.
Every weight in this archive was produced inside the SketchAI repository — by
`training/train_345.py` (original run) and then `training/refine_model_345.py`
(2026-11-20 refinement).

## Dataset

- Source:   Google Quick, Draw! (CC BY 4.0, (c) Google, Inc.)
- Access:   `quickdraw.js@1.0.6` npm package, a verbatim redistribution of the
            official dataset whose licence file carries the CC BY 4.0 attribution.
            (storage.googleapis.com and huggingface.co are unreachable from the
            training environment, so this mirror was used.)
- Classes:  345 — exactly the official Quick, Draw! list
- Examples per class: 100 (the mirror's ceiling; 34,500 total)
- Split:    27600 train / 3450 validation / 3450 test (80/10/10, seed 42)

## Input contract

- Shape:  [1, 28, 28, 1]
- Format: 28x28x1 float32, white ink on black, 0-1
- Output: 345 softmax probabilities

## Results (held-out test split, 3,450 drawings)

| model | top-1 | top-3 | top-10 | loss |
|---|---|---|---|---|
| production model, 2026-10-30 (60 epochs) | 37.71% | 58.12% | 76.12% | 2.824 |
| **this archive, 2026-11-20 (60 + 24 + 26 epochs)** | **40.09%** | **59.25%** | **77.62%** | **2.696** |

Paired comparison on the same 3,450 drawings: **+2.38 pp top-1**
(per-class cluster bootstrap 95% CI +1.42 … +3.36 pp; McNemar 169 drawings
fixed vs 87 broken, chi-square 25.6, p = 4.1e-7). Nothing was trained on the
test rows in either run.

- Random baseline: 0.29%
- Parameters: 214,649 (identical architecture, so the app's input contract and
  output order are unchanged)
- Sixteen hand-drawn doodles (`scripts/manual-test-345.mjs`, not a test split):
  top-1 6/16, top-3 9/16, top-10 14/16 — the previous weights scored 7/16, 9/16,
  12/16. One drawing flipped (umbrella, previously 63% correct, now 48% umbrella /
  45% mushroom); the extra top-10 hits are shoe, guitar and elephant. Sixteen
  samples cannot separate these weight sets, so treat that row as a smoke test of
  the browser code path, not as evidence.

The frozen 400-drawing app-pipeline benchmark (`scripts/evaluate-quickdraw-400.mjs`,
which replays `src/ai/preprocess.js` and the TF.js model) went from 152/400
(38.0%) to 158/400 (39.5%) top-1 with this archive installed.

## Training environment

- CPU only, no GPU
- Original run: TensorFlow 2.21.0 / tf-keras, Adam lr 1e-3, batch 128, 60 epochs,
  EarlyStopping + ReduceLROnPlateau + ModelCheckpoint, ~15 min
- Refinement: TensorFlow 2.20 CPU, Keras 3, batch 128 — 24 epochs on the train rows
  (cosine 2e-4, selected on validation, RandomZoom(0.06), label smoothing 0.05,
  ~7 min) then 26 epochs on train+validation rows with Adam EMA momentum 0.99
  (cosine 1e-4, ~8 min). Test rows untouched throughout.

## Architecture (unchanged)

    Conv2D(32, 3x3, same) -> BatchNorm -> ReLU -> MaxPool(2x2)
    Conv2D(64, 3x3, same) -> BatchNorm -> ReLU -> MaxPool(2x2)
    Conv2D(128, 3x3, same) -> ReLU
    GlobalAveragePooling2D -> Dense(256, relu) -> Dropout(0.4) -> Dense(345, softmax)

## Preprocessing (must match at inference)

White ink on black, 28x28x1 float32 in 0..1: ink bounding box -> centred square
`max(w, h) * 1.186` -> area-average to 28x28 -> lift the 97th-percentile ink
value to 1.0 (minimum gamma 0.25). Implemented in `src/ai/preprocess.js`
profile "345" and in `training/quickdraw_ndjson.py`.

## TF.js conversion notes

`public/model-345/` is produced by `training/export_model_345.py`. The raw
`tensorflowjs_converter` output of a Keras 3 model does **not** load in
tfjs-layers 4.x; two renames are required and the script applies them
automatically:

1. Keras 3 names the input layer's shape `batch_shape`; tfjs-layers needs
   `batch_input_shape`.
2. Keras 3 may prefix weights with the model name (`sketchai_345/conv2d/kernel`);
   tfjs-layers looks weights up by layer path (`conv2d/kernel`).

After patching, TF.js and Keras agree to max |dp| = 2.7e-7 and 16/16 top-1.

## Licence

Model weights: produced by this project; free to use with the app.
Dataset: Google Quick, Draw!, CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).
SketchAI is not affiliated with or endorsed by Google.
