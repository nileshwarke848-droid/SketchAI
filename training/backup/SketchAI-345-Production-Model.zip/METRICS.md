# SketchAI 345-class model — metrics and provenance

## What this is

SketchAI's own classifier trained on the Google Quick Draw dataset.
It is **not** Google's model, not AutoDraw, and not a third-party checkpoint.
Every weight in this archive was produced by `training/train_345.py` in the
SketchAI repository.

## Dataset

- Source:   Google Quick, Draw! (CC BY 4.0, (c) Google, Inc.)
- Access:   `quickdraw.js@1.0.6` npm package, a verbatim redistribution of the
            official dataset whose licence file carries the CC BY 4.0 attribution.
            (storage.googleapis.com and huggingface.co are unreachable from the
            training environment, so this mirror was used.)
- Classes:  345 — exactly the official Quick, Draw! list
- Examples per class: 100 (the mirror's ceiling; 34,500 total)
- Split:    27600 train / 3450 validation / 3450 test (80/10/10, seed 42)

## Input contract

- Shape:  [1, 28, 28, 1]
- Format: 28x28x1 float32, white ink on black, 0-1
- Output: 345 softmax probabilities

## Results (held-out test split)

- Top-1:  37.71%
- Top-3:  58.12%
- Top-10: 76.12%
- Random baseline: 0.29%
- Parameters: 214,649

Human hand-drawn doodle test (16 objects): top-1 7/16, top-3 9/16, top-10 12/16.

## Training environment

- CPU only, no GPU
- TensorFlow 2.21.0, tf-keras 2.21.0, Python 3.11
- Adam lr 1e-3, batch 128, 60 epochs (best restored), EarlyStopping +
  ReduceLROnPlateau + ModelCheckpoint
- ~12.5 minutes

## Architecture (unchanged)

    Conv2D(32, 3x3, same) -> BatchNorm -> ReLU -> MaxPool(2x2)
    Conv2D(64, 3x3, same) -> BatchNorm -> ReLU -> MaxPool(2x2)
    Conv2D(128, 3x3, same) -> ReLU
    GlobalAveragePooling2D -> Dense(256, relu) -> Dropout(0.4) -> Dense(345, softmax)

## Preprocessing (must match at inference)

White ink on black, 28x28x1 float32 in 0..1: ink bounding box -> centred square
`max(w, h) * 1.186` -> area-average to 28x28 -> lift the 97th-percentile ink
value to 1.0 (minimum gamma 0.25). Implemented in `src/ai/preprocess.js`
profile "345" and in `training/quickdraw_ndjson.py`.

## Licence

Model weights: produced by this project; free to use with the app.
Dataset: Google Quick, Draw!, CC BY 4.0 (https://creativecommons.org/licenses/by/4.0/).
SketchAI is not affiliated with or endorsed by Google.
